## Bedrock Eklenti Örnek Dosyaları Aşağıdaki örnek dosyalar, Minecraft: Bedrock Edition için Eklentiler oluşturmaya yönelik en son kaynak ve davranış örneklerini sağlar. 

Bu dosyaların kaynağı https://github.com/mojang/bedrock-samples adresinde mevcuttur. 
Minecraft için Eklentilerin nasıl oluşturulacağı hakkında daha fazla bilgi için lütfen https://minecraft.net/creator ve https://learn.microsoft.com/minecraft/creator adreslerini ziyaret edin. 