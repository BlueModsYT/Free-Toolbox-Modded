(c) Mojang AB. Her hakkı saklıdır. 

Bu depodaki dosyaları indirerek, [Minecraft Son Kullanıcı Lisans Sözleşmesini](https://www.minecraft.net/en-us/eula) ve bu dosyaların bu sözleşmenin şartlarına tabi olduğunu kabul etmiş olursunuz.

Bu modu değiştirip kendinizin gibi yayınlamanız takdirde telif hakkı ihtarı uygulanacaktır.

Bu modu direkt link veya kendi linklerinizi kullanarak paylaşamazsınız modu tanıtmak paylaşmak bazı şartlarımız mevcuttur;
 1- Modu bizim verdiğimiz linkten paylaşmanız gerekir.
 2- Modun sahibini açıklama kısmınızda [Credits: @fersred.official] bir şekilde yazmanız gerekir.
 3- Discord sunucumuza bulunmanız ve FerSReD Official'den modu paylaşmak için izin almanız gerekir.
 4- Modu paylaşmak için bizim verdiğimiz link ile beraber discord sunucumuzun davet davet linki olan (https://discord.gg/fersredofficial)'ı açıklamanızda bizim verdiğimiz linkin yanına eklemeniz gerekir.

Bu mod için koyduğumuz kurallar;
 1- Modumuzu çalıp veya alıp düzenleyip kendi adınıza paylaşmak yasaktır.
 2- Modumuzda değişiklik yapmak yasaktır.
 3- Modumuza bişeyler (dosya, resim, yazı v.b.) eklemek yasaktır.
 4- Modu kendi adınıza kullanmak yasaktır.

Bu modumuz hakkında bir sorununuz, şikayetiniz veya maruzatınız varsa discord sunucumuza gelerek modun sahibi FerSReD Official veya Mon3ster1 ile iletişime geçiniz.

Sorun & İstek & Şikayet için [Discord Sunucumuz](https://discord.gg/fersredofficial)'a gelebilirsiniz.

Developed By FerSReD Official & Mon3ster1